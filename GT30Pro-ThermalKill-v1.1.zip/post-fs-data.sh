#!/system/bin/sh
# ============================================================
# GT 30 Pro Thermal Kill v1.0 - post-fs-data.sh
# Jalankan SEBELUM boot: cegah vendor.thermal-mediatek restart
# ============================================================

# Disable thermal trip points via sysfs (early stage)
# Lebih efektif dari setprop karena langsung ke kernel
for zone in /sys/class/thermal/thermal_zone*; do
    # Set mode passive ke disabled
    echo "disabled" > "$zone/mode" 2>/dev/null
    # Set semua trip point ke 200°C
    for trip in "$zone"/trip_point_*_temp; do
        echo 200000 > "$trip" 2>/dev/null
    done
done

# VM tuning dasar
echo 0 > /proc/sys/vm/swappiness
echo 0 > /proc/sys/vm/panic_on_oom

exit 0
