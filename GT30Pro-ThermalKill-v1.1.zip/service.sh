#!/system/bin/sh
# ============================================================
# GT 30 Pro Thermal Kill v1.1 - service.sh
# FIXED: vendor.thermal-mediatek DIBIARKAN RUNNING
# Yang dibypass: thermal zones kernel + DVFS ceiling + cooling devices
# ============================================================
LOG_FILE="/data/local/tmp/gt30pro_thermal.log"

log_t() {
    log -t "GT30Pro-THERMAL" "$1" 2>/dev/null
    echo "$(date '+%H:%M:%S') $1" >> "$LOG_FILE" 2>/dev/null
}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done
sleep 6

> "$LOG_FILE"
log_t "=== Thermal Kill v1.1 STARTED ==="
log_t "    MODE: vendor.thermal-mediatek DIBIARKAN RUNNING"

# ============================================================
# [1] STOP SERVICE THERMAL LAIN (BUKAN vendor.thermal-mediatek)
# vendor.thermal-mediatek TIDAK disentuh sesuai permintaan
# Hanya matikan service thermal duplikat / tidak penting
# ============================================================
log_t "[1] Stopping non-essential thermal services (skip vendor.thermal-mediatek)..."

stop android.hardware.thermal-service.mediatek 2>/dev/null
stop thermal_core                              2>/dev/null
stop thermald                                  2>/dev/null

# Kill proses thermal SELAIN vendor.thermal-mediatek
for pid in $(pgrep -f thermal 2>/dev/null); do
    PNAME=$(cat /proc/${pid}/comm 2>/dev/null)
    case "$PNAME" in
        *thermal*|*Thermal*)
            # SKIP vendor.thermal-mediatek — jangan disentuh
            case "$PNAME" in
                *vendor.thermal-mediatek*|*thermal-mediatek*)
                    log_t "[1] SKIP (dilindungi): $PNAME (PID $pid)"
                    continue
                    ;;
            esac
            kill -9 "$pid" 2>/dev/null
            log_t "[1] Killed: $PNAME (PID $pid)"
            ;;
    esac
done

setprop ctl.stop "android.hardware.thermal-service.mediatek"
setprop ctl.stop "thermal_core"
setprop ctl.stop "thermald"
# TIDAK setprop ctl.stop "vendor.thermal-mediatek"

log_t "[1] Done (vendor.thermal-mediatek tetap running)"

# ============================================================
# [2] DISABLE THERMAL TRIP POINTS DI KERNEL - AGRESIF
# ============================================================
log_t "[2] Disabling kernel thermal zones..."

ZONE_COUNT=0
for zone in /sys/class/thermal/thermal_zone*; do
    echo "disabled" > "$zone/mode" 2>/dev/null && ZONE_COUNT=$((ZONE_COUNT+1))
    for trip in "$zone"/trip_point_*_temp; do
        echo 200000 > "$trip" 2>/dev/null
    done
    echo "user_space" > "$zone/policy" 2>/dev/null
done
log_t "[2] $ZONE_COUNT thermal zones disabled"

# ============================================================
# [3] COOLING DEVICES - FORCE STATE 0
# ============================================================
log_t "[3] Zeroing all cooling devices..."

CDEV_COUNT=0
for cdev in /sys/class/thermal/cooling_device*; do
    echo 0 > "$cdev/cur_state" 2>/dev/null && CDEV_COUNT=$((CDEV_COUNT+1))
done
log_t "[3] $CDEV_COUNT cooling devices set to state 0"

# ============================================================
# [4] CPU FREQ LOCK - SEMUA CORE MAX
# ============================================================
log_t "[4] Re-locking CPU frequencies..."

for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    echo "performance" > "$cpu/scaling_governor" 2>/dev/null
done

for i in 0 1 2 3 4 5 6 7; do
    MAX=$(cat /sys/devices/system/cpu/cpu${i}/cpufreq/cpuinfo_max_freq 2>/dev/null)
    if [ -n "$MAX" ]; then
        echo "$MAX" > /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq 2>/dev/null
        echo "$MAX" > /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_min_freq 2>/dev/null
        log_t "[4] CPU$i locked at ${MAX}kHz"
    fi
done

for limit_file in \
    /sys/devices/system/cpu/cpu_boost/input_boost_freq \
    /proc/cpufreq/cpufreq_power_mode \
    /proc/cpufreq/cpufreq_ptpod_temperature_limit; do
    [ -f "$limit_file" ] && echo 0 > "$limit_file" 2>/dev/null
done

for ceiling in /sys/kernel/debug/cpufreq/*/ceiling_freq; do
    MAX_C=$(cat "${ceiling%ceiling_freq}max_freq" 2>/dev/null)
    [ -n "$MAX_C" ] && echo "$MAX_C" > "$ceiling" 2>/dev/null
done

log_t "[4] CPU freq locked OK"

# ============================================================
# [5] GPU FREQ LOCK
# ============================================================
log_t "[5] Re-locking GPU..."

for GPU_PATH in \
    /sys/devices/platform/13000000.mali/devfreq/13000000.mali \
    /sys/devices/platform/13040000.mali/devfreq/13040000.mali \
    /sys/class/misc/mali0/device/devfreq/devfreq0; do
    [ -d "$GPU_PATH" ] || continue
    MAX_GPU=$(cat "$GPU_PATH/max_freq" 2>/dev/null)
    if [ -n "$MAX_GPU" ]; then
        echo "performance" > "$GPU_PATH/governor" 2>/dev/null
        echo "$MAX_GPU"   > "$GPU_PATH/min_freq"  2>/dev/null
        log_t "[5] GPU locked at ${MAX_GPU}Hz"
    fi
done

echo "always_on"   > /sys/class/misc/mali0/device/power_policy  2>/dev/null
echo "performance" > /sys/class/misc/mali0/device/dvfs_policy    2>/dev/null

for gpu_ceil in /sys/class/misc/mali0/device/devfreq/*/max_freq; do
    MAX_G=$(cat "${gpu_ceil%max_freq}max_freq" 2>/dev/null)
    [ -n "$MAX_G" ] && echo "$MAX_G" > "$gpu_ceil" 2>/dev/null
done

log_t "[5] GPU locked OK"

# ============================================================
# [6] APU/NPU UNLOCK
# ============================================================
log_t "[6] Unlocking APU/NPU..."

for APU_PATH in \
    /sys/devices/platform/10990000.apusys/devfreq/10990000.apusys \
    /sys/bus/platform/devices/10990000.apusys/devfreq/* \
    /sys/class/devfreq/mtk-apu*; do
    [ -d "$APU_PATH" ] || continue
    MAX_APU=$(cat "$APU_PATH/max_freq" 2>/dev/null)
    if [ -n "$MAX_APU" ]; then
        echo "performance" > "$APU_PATH/governor" 2>/dev/null
        echo "$MAX_APU"   > "$APU_PATH/min_freq"  2>/dev/null
        log_t "[6] APU locked at ${MAX_APU}Hz"
    fi
done

for apu_v in /sys/kernel/debug/apusys*/power*; do
    [ -f "$apu_v" ] && echo 1 > "$apu_v" 2>/dev/null
done

[ -f /proc/apusys/freq ] && cat /proc/apusys/freq >> "$LOG_FILE" 2>/dev/null

for mdla in /sys/class/devfreq/mtk-mdla*; do
    [ -d "$mdla" ] || continue
    MAX_MDLA=$(cat "$mdla/max_freq" 2>/dev/null)
    [ -n "$MAX_MDLA" ] && echo "$MAX_MDLA" > "$mdla/min_freq" 2>/dev/null
    echo "performance" > "$mdla/governor" 2>/dev/null
done

log_t "[6] APU/NPU unlocked"

# ============================================================
# [7] BATTERY THROTTLE DISABLE
# ============================================================
log_t "[7] Disabling battery throttle..."

for bat_limit in \
    /sys/devices/platform/battery_meter/power_throttling \
    /sys/class/power_supply/battery/power_cap \
    /proc/mtk_battery_cmd/current_cmd \
    /sys/kernel/debug/mtk_battery/battery_throttle; do
    [ -f "$bat_limit" ] && echo 0 > "$bat_limit" 2>/dev/null && \
        log_t "[7] Disabled: $bat_limit"
done

setprop persist.vendor.powerhal.battery.disable 1
setprop persist.vendor.battery.perf.disable 1
setprop persist.sys.perf.battery.disable 1

log_t "[7] Battery throttle disabled"

# ============================================================
# [8] SCHEDTUNE & EAS BYPASS
# ============================================================
log_t "[8] Tuning CPU scheduler..."

echo 100 > /dev/stune/top-app/schedtune.boost       2>/dev/null
echo 1   > /dev/stune/top-app/schedtune.prefer_idle  2>/dev/null
echo 100 > /dev/stune/foreground/schedtune.boost     2>/dev/null
echo 1   > /dev/stune/foreground/schedtune.prefer_idle 2>/dev/null
echo 50  > /dev/stune/background/schedtune.boost     2>/dev/null

echo 0 > /proc/sys/kernel/sched_cfs_bandwidth_slice_us 2>/dev/null
echo 0 > /proc/sys/kernel/sched_autogroup_enabled 2>/dev/null
echo 0 > /dev/cpu_dma_latency 2>/dev/null
echo 1 > /sys/devices/system/cpu/cpufreq/boost 2>/dev/null

log_t "[8] Scheduler tuned"

# ============================================================
# [9] MTK DVFS CEILING REMOVE
# ============================================================
log_t "[9] Removing MTK DVFS thermal ceiling..."

for freq_ceiling in \
    /proc/cpufreq/cpufreq_limited_by_thermal \
    /proc/cpufreq/cpufreq_thermal_limited \
    /sys/kernel/debug/cpufreq/thermal_limit; do
    [ -f "$freq_ceiling" ] && echo 0 > "$freq_ceiling" 2>/dev/null
done

for mtk_limit in \
    /proc/mtk_thermal/thermal_throttle \
    /proc/thermal/thermal_throttle \
    /sys/kernel/debug/thermal/thermal_limit; do
    [ -f "$mtk_limit" ] && echo 0 > "$mtk_limit" 2>/dev/null
done

log_t "[9] DVFS ceiling removed"

# ============================================================
# [10] WATCHDOG - VERSI AMAN
# HANYA reset cooling devices & re-lock freq
# TIDAK mematikan vendor.thermal-mediatek
# ============================================================
log_t "[10] Starting safe thermal watchdog..."

(while true; do
    # HANYA cek android.hardware.thermal-service.mediatek (bukan vendor.thermal-mediatek)
    THERMAL_SVC=$(getprop init.svc.android.hardware.thermal-service.mediatek)
    if [ "$THERMAL_SVC" = "running" ]; then
        setprop ctl.stop "android.hardware.thermal-service.mediatek"
        log_t "[WDG] android.hardware.thermal-service.mediatek restart → killed"

        # Re-lock CPU setelah thermal restart
        for i in 0 1 2 3 4 5 6 7; do
            MAX=$(cat /sys/devices/system/cpu/cpu${i}/cpufreq/cpuinfo_max_freq 2>/dev/null)
            [ -n "$MAX" ] && echo "$MAX" > /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_min_freq 2>/dev/null
        done
    fi

    # vendor.thermal-mediatek: JANGAN disentuh — cukup reset cooling devices
    # agar throttle dari sisinya tidak berlaku di hardware
    for cdev in /sys/class/thermal/cooling_device*/cur_state; do
        STATE=$(cat "$cdev" 2>/dev/null)
        if [ -n "$STATE" ] && [ "$STATE" -gt 0 ] 2>/dev/null; then
            echo 0 > "$cdev" 2>/dev/null
            log_t "[WDG] Reset cooling device: $cdev was $STATE"
        fi
    done

    sleep 5
done) &

WATCHDOG_PID=$!
log_t "[10] Safe watchdog PID: $WATCHDOG_PID"

# ============================================================
# DONE
# ============================================================
THERMAL_MTK=$(getprop init.svc.vendor.thermal-mediatek)
THERMAL_HAL=$(getprop init.svc.android.hardware.thermal-service.mediatek)
CPU0_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null)
CPU7_FREQ=$(cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq 2>/dev/null)

log_t "=== VERIFIKASI ==="
log_t "  vendor.thermal-mediatek          : $THERMAL_MTK (harus: running)"
log_t "  android.hardware.thermal-service : $THERMAL_HAL (harus: stopped)"
log_t "  CPU0 freq    : ${CPU0_FREQ}kHz"
log_t "  CPU7 freq    : ${CPU7_FREQ}kHz"
log_t "  Watchdog     : RUNNING SAFE (PID $WATCHDOG_PID)"
log_t "=== Thermal Kill v1.1 selesai ==="

exit 0
